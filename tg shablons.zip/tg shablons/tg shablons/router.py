"""
MODULE: faq
Показывает список вопросов → по нажатию выдаёт ответ.
Данные берёт из config.json → "faq" → "items".
"""
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery

from core.loader import config
from core.keyboards import build_faq_inline, build_back_button

router = Router()

# ── Trigger: кнопка из главного меню ─────────────────────────────────────────
@router.message(F.text == config["modules"]["faq"]["button_text"])
async def faq_menu(message: Message):
    faq_items = config["faq"]["items"]

    if not faq_items:
        await message.answer("Раздел FAQ пока пуст.", reply_markup=build_back_button())
        return

    await message.answer(
        text="❓ <b>Часто задаваемые вопросы</b>\n\nВыберите вопрос, который вас интересует:",
        reply_markup=build_faq_inline(faq_items),
        parse_mode="HTML"
    )
    # Показываем кнопку «Назад» отдельным reply-сообщением
    await message.answer("Или вернитесь в главное меню:", reply_markup=build_back_button())


# ── Inline: пользователь нажал на конкретный вопрос ──────────────────────────
@router.callback_query(F.data.startswith("faq:"))
async def faq_answer(callback: CallbackQuery):
    index = int(callback.data.split(":")[1])
    faq_items = config["faq"]["items"]

    if index >= len(faq_items):
        await callback.answer("Вопрос не найден.", show_alert=True)
        return

    item = faq_items[index]
    await callback.message.answer(
        text=f"❓ <b>{item['question']}</b>\n\n{item['answer']}",
        parse_mode="HTML",
        reply_markup=build_back_button()
    )
    await callback.answer()  # убираем «часики» на кнопке
