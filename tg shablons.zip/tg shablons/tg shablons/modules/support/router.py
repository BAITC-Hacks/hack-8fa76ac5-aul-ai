from html import escape

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from core.database import get_db
from core.email_sender import send_request_email
from core.keyboards import build_back_button, build_cancel_inline
from core.loader import config

router = Router()
MAIN_MENU_BUTTONS = {
    item["button_text"] for item in config["modules"].values() if item.get("enabled")
}


class SupportFlow(StatesGroup):
    full_name = State()
    contact = State()
    problem = State()
    confirm = State()


def _confirmation_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="Отправить", callback_data="support_confirm"),
        InlineKeyboardButton(text="Отмена", callback_data="support_cancel"),
    ]])


async def _require_text(message: Message, max_length: int) -> str | None:
    text = (message.text or "").strip()
    if not text:
        await message.answer("Пожалуйста, отправьте ответ текстовым сообщением.")
        return None
    if len(text) > max_length:
        await message.answer(f"Ответ слишком длинный. Максимум: {max_length} символов.")
        return None
    return text


@router.message(F.text == config["modules"]["support"]["button_text"])
async def support_start(message: Message, state: FSMContext):
    await state.clear()
    await state.set_state(SupportFlow.full_name)
    await message.answer(
        "Техническая поддержка\n\nУкажите ваше имя или название компании:",
        reply_markup=build_cancel_inline(),
    )


@router.message(SupportFlow.full_name, ~F.text.in_(MAIN_MENU_BUTTONS))
async def support_name(message: Message, state: FSMContext):
    text = await _require_text(message, 100)
    if text is None:
        return
    await state.update_data(full_name=text)
    await state.set_state(SupportFlow.contact)
    await message.answer(
        "Укажите телефон или email для обратной связи:",
        reply_markup=build_cancel_inline(),
    )


@router.message(SupportFlow.contact, ~F.text.in_(MAIN_MENU_BUTTONS))
async def support_contact(message: Message, state: FSMContext):
    text = await _require_text(message, 200)
    if text is None:
        return
    await state.update_data(contact=text)
    await state.set_state(SupportFlow.problem)
    await message.answer(
        "Опишите вопрос или проблему:",
        reply_markup=build_cancel_inline(),
    )


@router.message(SupportFlow.problem, ~F.text.in_(MAIN_MENU_BUTTONS))
async def support_problem(message: Message, state: FSMContext):
    text = await _require_text(message, 3000)
    if text is None:
        return
    await state.update_data(problem=text)
    data = await state.get_data()
    await state.set_state(SupportFlow.confirm)
    await message.answer(
        "<b>Проверьте заявку</b>\n\n"
        f"Имя/компания: {escape(data['full_name'])}\n"
        f"Контакт: {escape(data['contact'])}\n"
        f"Сообщение: {escape(data['problem'])}",
        parse_mode="HTML",
        reply_markup=_confirmation_keyboard(),
    )


@router.callback_query(SupportFlow.confirm, F.data == "support_confirm")
async def support_confirm(callback: CallbackQuery, state: FSMContext):
    await callback.answer("Обрабатываем заявку...")
    data = await state.get_data()

    db = await get_db()
    try:
        cursor = await db.execute(
            """INSERT INTO support_requests (tg_id, full_name, contact, message)
               VALUES (?, ?, ?, ?)""",
            (callback.from_user.id, data["full_name"], data["contact"], data["problem"]),
        )
        await db.commit()
        request_id = cursor.lastrowid
    finally:
        await db.close()
    await state.clear()

    delivered = await send_request_email(
        f"Заявка в техподдержку #{request_id}",
        "Новая заявка в техподдержку\n\n"
        f"Номер: {request_id}\n"
        f"Telegram ID: {callback.from_user.id}\n"
        f"Имя/компания: {data['full_name']}\n"
        f"Контакт: {data['contact']}\n"
        f"Сообщение: {data['problem']}",
    )
    status = "Заявка отправлена в техподдержку." if delivered else (
        "Заявка сохранена, но письмо не отправлено. Проверьте настройки SMTP."
    )
    await callback.message.answer(
        f"{status}\nНомер заявки: <b>#{request_id}</b>",
        parse_mode="HTML",
        reply_markup=build_back_button(),
    )


@router.callback_query(
    StateFilter(
        SupportFlow.full_name,
        SupportFlow.contact,
        SupportFlow.problem,
        SupportFlow.confirm,
    ),
    F.data.in_({"cancel", "support_cancel"}),
)
async def support_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.answer("Заявка отменена.", reply_markup=build_back_button())
    await callback.answer()
