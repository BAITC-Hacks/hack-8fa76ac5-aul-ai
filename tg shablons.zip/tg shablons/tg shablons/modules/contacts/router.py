"""
MODULE: contacts
Выводит адрес, телефон, соцсети и часы работы из config.json → "contacts".
"""
from aiogram import Router, F
from aiogram.types import Message

from core.loader import config
from core.keyboards import build_back_button

router = Router()


@router.message(F.text == config["modules"]["contacts"]["button_text"])
async def contacts_info(message: Message):
    c = config["contacts"]

    lines = ["📍 <b>Контакты и адрес</b>\n"]

    if c.get("address"):
        lines.append(f"🏠 <b>Адрес:</b> {c['address']}")
    if c.get("phone"):
        lines.append(f"📞 <b>Телефон:</b> {c['phone']}")
    if c.get("instagram"):
        lines.append(f"📸 <b>Instagram:</b> {c['instagram']}")
    if c.get("work_hours"):
        lines.append(f"🕐 <b>Часы работы:</b> {c['work_hours']}")

    await message.answer(
        text="\n".join(lines),
        parse_mode="HTML",
        reply_markup=build_back_button()
    )
