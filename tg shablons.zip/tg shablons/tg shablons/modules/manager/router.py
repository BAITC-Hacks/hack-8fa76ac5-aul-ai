"""
MODULE: manager
Пересылает сообщение пользователя менеджеру (MANAGER_CHAT_ID из .env).
Это самый легко отключаемый модуль — просто "manager": { "enabled": false }.
"""
import os
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from core.loader import config
from core.keyboards import build_back_button, build_cancel_inline

router = Router()

MANAGER_CHAT_ID = os.getenv("MANAGER_CHAT_ID")


# ── FSM States ────────────────────────────────────────────────────────────────
class ManagerFlow(StatesGroup):
    waiting_for_message = State()


# ── Step 1: пользователь нажал кнопку ────────────────────────────────────────
@router.message(F.text == config["modules"]["manager"]["button_text"])
async def manager_start(message: Message, state: FSMContext):
    if not MANAGER_CHAT_ID:
        await message.answer(
            "⚠️ Функция временно недоступна. Свяжитесь с нами по телефону.",
            reply_markup=build_back_button()
        )
        return

    await state.set_state(ManagerFlow.waiting_for_message)
    await message.answer(
        text=(
            "💬 <b>Написать менеджеру</b>\n\n"
            "Напишите ваш вопрос или проблему — менеджер ответит вам в ближайшее время.\n\n"
            "Можно отправить текст, фото или голосовое сообщение."
        ),
        parse_mode="HTML",
        reply_markup=build_cancel_inline()
    )


# ── Step 2: получаем сообщение и пересылаем менеджеру ─────────────────────────
@router.message(ManagerFlow.waiting_for_message)
async def manager_receive(message: Message, state: FSMContext, bot: Bot):
    await state.clear()

    user = message.from_user
    header = (
        f"📩 <b>Новое сообщение от клиента</b>\n"
        f"👤 {user.full_name} | @{user.username or '—'} | ID: {user.id}"
    )

    try:
        # Отправляем шапку менеджеру
        await bot.send_message(
            chat_id=MANAGER_CHAT_ID,
            text=header,
            parse_mode="HTML"
        )
        # Пересылаем само сообщение (любой тип: текст, фото, голос…)
        await message.forward(chat_id=MANAGER_CHAT_ID)

        await message.answer(
            "✅ Ваше сообщение отправлено! Менеджер ответит вам в ближайшее время.",
            reply_markup=build_back_button()
        )
    except Exception as e:
        await message.answer(
            "⚠️ Не удалось отправить сообщение. Попробуйте позже.",
            reply_markup=build_back_button()
        )


# ── Отмена через inline-кнопку ────────────────────────────────────────────────
@router.callback_query(ManagerFlow.waiting_for_message, F.data == "cancel")
async def manager_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.answer(
        "Отменено. Возвращаемся в меню.",
        reply_markup=build_back_button()
    )
    await callback.answer()
