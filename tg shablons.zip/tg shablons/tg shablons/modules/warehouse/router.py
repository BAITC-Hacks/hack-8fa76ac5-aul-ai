from datetime import date, datetime, timedelta, timezone
from html import escape
import re

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from core.database import get_db
from core.email_sender import send_request_email
from core.keyboards import build_back_button, build_cancel_inline
from core.loader import config

router = Router()
DATE_FORMAT = "%d.%m.%Y"
MAIN_MENU_BUTTONS = {
    item["button_text"] for item in config["modules"].values() if item.get("enabled")
}


class WarehouseFlow(StatesGroup):
    warehouse = State()
    date_from = State()
    date_to = State()
    contact = State()
    confirm = State()


def _warehouses_keyboard() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=item["name"], callback_data=f"warehouse:{index}")]
        for index, item in enumerate(config["warehouses"])
    ]
    rows.append([InlineKeyboardButton(text="Отмена", callback_data="warehouse_cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _confirmation_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="Отправить", callback_data="warehouse_confirm"),
        InlineKeyboardButton(text="Отмена", callback_data="warehouse_cancel"),
    ]])


def _parse_date(value: str) -> date | None:
    if not re.fullmatch(r"\d{2}\.\d{2}\.\d{4}", value.strip()):
        return None
    try:
        return datetime.strptime(value.strip(), DATE_FORMAT).date()
    except ValueError:
        return None


@router.message(F.text == config["modules"]["warehouse"]["button_text"])
async def warehouse_start(message: Message, state: FSMContext):
    await state.clear()
    await state.set_state(WarehouseFlow.warehouse)
    await message.answer(
        "<b>Аренда склада целиком</b>\n\nВыберите склад:",
        parse_mode="HTML",
        reply_markup=_warehouses_keyboard(),
    )


@router.callback_query(WarehouseFlow.warehouse, F.data.startswith("warehouse:"))
async def warehouse_selected(callback: CallbackQuery, state: FSMContext):
    try:
        index = int(callback.data.split(":", 1)[1])
        warehouse = config["warehouses"][index]
    except (ValueError, IndexError):
        await callback.answer("Склад не найден.", show_alert=True)
        return

    await state.update_data(
        warehouse_name=warehouse["name"],
        warehouse_address=warehouse["address"],
        utc_offset_hours=warehouse.get("utc_offset_hours", 0),
    )
    await state.set_state(WarehouseFlow.date_from)
    await callback.message.answer(
        f"Выбран: <b>{escape(warehouse['name'])}</b>\n"
        f"Адрес: {escape(warehouse['address'])}\n\n"
        "Введите дату начала аренды в формате ДД.ММ.ГГГГ:",
        parse_mode="HTML",
        reply_markup=build_cancel_inline(),
    )
    await callback.answer()


@router.message(WarehouseFlow.date_from, ~F.text.in_(MAIN_MENU_BUTTONS))
async def warehouse_date_from(message: Message, state: FSMContext):
    value = _parse_date(message.text or "")
    if value is None:
        await message.answer("Неверная дата. Введите её в формате ДД.ММ.ГГГГ, например 25.12.2026.")
        return
    data = await state.get_data()
    utc_now = datetime.now(timezone.utc).replace(tzinfo=None)
    warehouse_today = (
        utc_now + timedelta(hours=float(data["utc_offset_hours"]))
    ).date()
    if value < warehouse_today:
        await message.answer("Дата начала не может быть в прошлом. Введите другую дату.")
        return

    await state.update_data(date_from=value.isoformat())
    await state.set_state(WarehouseFlow.date_to)
    await message.answer(
        "Введите дату окончания аренды в формате ДД.ММ.ГГГГ:",
        reply_markup=build_cancel_inline(),
    )


@router.message(WarehouseFlow.date_to, ~F.text.in_(MAIN_MENU_BUTTONS))
async def warehouse_date_to(message: Message, state: FSMContext):
    value = _parse_date(message.text or "")
    if value is None:
        await message.answer("Неверная дата. Введите её в формате ДД.ММ.ГГГГ.")
        return
    data = await state.get_data()
    if value < date.fromisoformat(data["date_from"]):
        await message.answer("Дата окончания не может быть раньше даты начала.")
        return

    await state.update_data(date_to=value.isoformat())
    await state.set_state(WarehouseFlow.contact)
    await message.answer(
        "Укажите телефон или email для связи:",
        reply_markup=build_cancel_inline(),
    )


@router.message(WarehouseFlow.contact, ~F.text.in_(MAIN_MENU_BUTTONS))
async def warehouse_contact(message: Message, state: FSMContext):
    contact = (message.text or "").strip()
    if not contact:
        await message.answer("Пожалуйста, отправьте контакт текстовым сообщением.")
        return
    if len(contact) > 200:
        await message.answer("Контакт слишком длинный. Максимум: 200 символов.")
        return

    await state.update_data(contact=contact)
    data = await state.get_data()
    date_from = date.fromisoformat(data["date_from"])
    date_to = date.fromisoformat(data["date_to"])
    days = (date_to - date_from).days + 1
    await state.set_state(WarehouseFlow.confirm)
    await message.answer(
        "<b>Проверьте заявку на аренду всего склада</b>\n\n"
        f"Склад: {escape(data['warehouse_name'])}\n"
        f"Адрес: {escape(data['warehouse_address'])}\n"
        f"Период: {date_from.strftime(DATE_FORMAT)} - {date_to.strftime(DATE_FORMAT)}\n"
        f"Срок: {days} дн.\n"
        f"Контакт: {escape(data['contact'])}",
        parse_mode="HTML",
        reply_markup=_confirmation_keyboard(),
    )


@router.callback_query(WarehouseFlow.confirm, F.data == "warehouse_confirm")
async def warehouse_confirm(callback: CallbackQuery, state: FSMContext):
    await callback.answer("Обрабатываем заявку...")
    data = await state.get_data()

    db = await get_db()
    try:
        cursor = await db.execute(
            """INSERT INTO warehouse_requests
               (tg_id, warehouse_name, warehouse_address, date_from, date_to, contact)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                callback.from_user.id,
                data["warehouse_name"],
                data["warehouse_address"],
                data["date_from"],
                data["date_to"],
                data["contact"],
            ),
        )
        await db.commit()
        request_id = cursor.lastrowid
    finally:
        await db.close()
    await state.clear()

    delivered = await send_request_email(
        f"Заявка на аренду склада #{request_id}",
        "Новая заявка на аренду склада целиком\n\n"
        f"Номер: {request_id}\n"
        f"Telegram ID: {callback.from_user.id}\n"
        f"Склад: {data['warehouse_name']}\n"
        f"Адрес: {data['warehouse_address']}\n"
        f"Начало: {data['date_from']}\n"
        f"Окончание: {data['date_to']}\n"
        f"Контакт: {data['contact']}",
    )
    status = "Заявка отправлена." if delivered else (
        "Заявка сохранена, но письмо не отправлено. Проверьте настройки SMTP."
    )
    await callback.message.answer(
        f"{status}\nНомер заявки: <b>#{request_id}</b>",
        parse_mode="HTML",
        reply_markup=build_back_button(),
    )


@router.callback_query(
    StateFilter(
        WarehouseFlow.warehouse,
        WarehouseFlow.date_from,
        WarehouseFlow.date_to,
        WarehouseFlow.contact,
        WarehouseFlow.confirm,
    ),
    F.data.in_({"cancel", "warehouse_cancel"}),
)
async def warehouse_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.answer("Заявка отменена.", reply_markup=build_back_button())
    await callback.answer()
