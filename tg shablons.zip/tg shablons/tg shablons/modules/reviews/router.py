"""
MODULE: reviews
Сбор отзывов: пользователь ставит оценку звёздочками → пишет текст → сохраняется в БД.
"""
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter

from core.loader import config
from core.keyboards import build_rating_inline, build_back_button, build_cancel_inline
from core.database import get_db

router = Router()


# ── FSM States ────────────────────────────────────────────────────────────────
class ReviewFlow(StatesGroup):
    waiting_for_rating = State()
    waiting_for_text   = State()


# ── Step 1: вход в модуль ─────────────────────────────────────────────────────
@router.message(F.text == config["modules"]["reviews"]["button_text"])
async def reviews_start(message: Message, state: FSMContext):
    await state.set_state(ReviewFlow.waiting_for_rating)
    await message.answer(
        text="⭐ <b>Оставить отзыв</b>\n\nКак вы оцените нас?",
        parse_mode="HTML",
        reply_markup=build_rating_inline()
    )


# ── Step 2: пользователь выбрал оценку ───────────────────────────────────────
@router.callback_query(ReviewFlow.waiting_for_rating, F.data.startswith("rating:"))
async def reviews_get_rating(callback: CallbackQuery, state: FSMContext):
    rating = int(callback.data.split(":")[1])
    await state.update_data(rating=rating)
    await state.set_state(ReviewFlow.waiting_for_text)

    stars = "⭐" * rating
    await callback.message.answer(
        text=f"Вы поставили: {stars}\n\nТеперь напишите небольшой отзыв (можно пару слов):",
        reply_markup=build_cancel_inline()
    )
    await callback.answer()


# ── Step 3: получаем текст, сохраняем в БД ───────────────────────────────────
@router.message(ReviewFlow.waiting_for_text)
async def reviews_save(message: Message, state: FSMContext):
    data = await state.get_data()
    rating = data.get("rating", 5)
    await state.clear()

    db = await get_db()
    try:
        await db.execute(
            "INSERT INTO reviews (tg_id, text, rating) VALUES (?, ?, ?)",
            (message.from_user.id, message.text, rating)
        )
        await db.commit()
    finally:
        await db.close()

    stars = "⭐" * rating
    await message.answer(
        text=(
            f"✅ <b>Спасибо за ваш отзыв!</b>\n\n"
            f"Оценка: {stars}\n"
            f"Текст: {message.text}"
        ),
        parse_mode="HTML",
        reply_markup=build_back_button()
    )


# ── Отмена ────────────────────────────────────────────────────────────────────
@router.callback_query(StateFilter(ReviewFlow.waiting_for_rating, ReviewFlow.waiting_for_text), F.data == "cancel")
async def reviews_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.answer("Отменено.", reply_markup=build_back_button())
    await callback.answer()
