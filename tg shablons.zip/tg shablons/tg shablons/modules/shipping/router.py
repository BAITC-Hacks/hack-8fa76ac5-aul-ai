from datetime import datetime, timedelta, timezone
from html import escape
import re

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from core.database import get_db
from core.email_sender import send_request_email
from core.keyboards import build_back_button, build_cancel_inline
from core.loader import config
from core.shipping import estimate_route, format_duration

router = Router()
DATETIME_FORMAT = "%d.%m.%Y %H:%M"
TRANSPORT_NAMES = {"air": "Полный самолёт", "sea": "Полное судно"}
MAIN_MENU_BUTTONS = {
    item["button_text"] for item in config["modules"].values() if item.get("enabled")
}


class ShippingFlow(StatesGroup):
    transport = State()
    origin = State()
    destination = State()
    departure = State()
    contact = State()
    confirm = State()


def _transport_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Полный самолёт", callback_data="shipping_transport:air")],
        [InlineKeyboardButton(text="Полное судно", callback_data="shipping_transport:sea")],
        [InlineKeyboardButton(text="Отмена", callback_data="shipping_cancel")],
    ])


def _locations_keyboard(prefix: str, excluded_index: int | None = None) -> InlineKeyboardMarkup:
    rows = []
    for index, location in enumerate(config["shipping"]["locations"]):
        if index != excluded_index:
            rows.append([InlineKeyboardButton(
                text=location["name"],
                callback_data=f"{prefix}:{index}",
            )])
    rows.append([InlineKeyboardButton(text="Отмена", callback_data="shipping_cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _confirmation_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="Отправить", callback_data="shipping_confirm"),
        InlineKeyboardButton(text="Отмена", callback_data="shipping_cancel"),
    ]])


def _location_address(location: dict, transport: str) -> str:
    return location["air_address" if transport == "air" else "sea_address"]


def _format_utc_offset(value: float) -> str:
    sign = "+" if value >= 0 else "-"
    total_minutes = round(abs(value) * 60)
    hours, minutes = divmod(total_minutes, 60)
    suffix = f":{minutes:02d}" if minutes else ""
    return f"UTC{sign}{hours}{suffix}"


def _route_text(data: dict) -> str:
    departure = datetime.fromisoformat(data["departure_at"])
    arrival = datetime.fromisoformat(data["arrival_at"])
    locations = config["shipping"]["locations"]
    origin_offset = locations[data["origin_index"]]["utc_offset_hours"]
    destination_offset = locations[data["destination_index"]]["utc_offset_hours"]
    return (
        f"Транспорт: {escape(TRANSPORT_NAMES[data['transport']])}\n"
        f"Откуда: {escape(data['origin_name'])}\n"
        f"Адрес отправления: {escape(data['origin_address'])}\n"
        f"Куда: {escape(data['destination_name'])}\n"
        f"Адрес прибытия: {escape(data['destination_address'])}\n"
        f"Отправление: {departure.strftime(DATETIME_FORMAT)} "
        f"({_format_utc_offset(origin_offset)})\n"
        f"Расстояние: около {data['distance_km']} км\n"
        f"Расчётное время в пути: {format_duration(data['duration_minutes'])}\n"
        f"Расчётное прибытие: {arrival.strftime(DATETIME_FORMAT)} "
        f"({_format_utc_offset(destination_offset)})"
    )


@router.message(F.text == config["modules"]["shipping"]["button_text"])
async def shipping_start(message: Message, state: FSMContext):
    await state.clear()
    await state.set_state(ShippingFlow.transport)
    await message.answer(
        "<b>Перевозка груза</b>\n\nВыберите тип транспорта:",
        parse_mode="HTML",
        reply_markup=_transport_keyboard(),
    )


@router.callback_query(ShippingFlow.transport, F.data.startswith("shipping_transport:"))
async def shipping_transport(callback: CallbackQuery, state: FSMContext):
    transport = callback.data.split(":", 1)[1]
    if transport not in TRANSPORT_NAMES:
        await callback.answer("Неизвестный тип транспорта.", show_alert=True)
        return
    await state.update_data(transport=transport)
    await state.set_state(ShippingFlow.origin)
    await callback.message.answer(
        f"Выбрано: <b>{TRANSPORT_NAMES[transport]}</b>\n\nВыберите пункт отправления:",
        parse_mode="HTML",
        reply_markup=_locations_keyboard("shipping_origin"),
    )
    await callback.answer()


@router.callback_query(ShippingFlow.origin, F.data.startswith("shipping_origin:"))
async def shipping_origin(callback: CallbackQuery, state: FSMContext):
    try:
        index = int(callback.data.split(":", 1)[1])
        location = config["shipping"]["locations"][index]
    except (ValueError, IndexError):
        await callback.answer("Пункт не найден.", show_alert=True)
        return
    data = await state.get_data()
    address = _location_address(location, data["transport"])
    await state.update_data(
        origin_index=index,
        origin_name=location["name"],
        origin_address=address,
    )
    await state.set_state(ShippingFlow.destination)
    await callback.message.answer(
        f"Отправление: <b>{escape(location['name'])}</b>\n"
        f"{escape(address)}\n\nВыберите пункт прибытия:",
        parse_mode="HTML",
        reply_markup=_locations_keyboard("shipping_destination", excluded_index=index),
    )
    await callback.answer()


@router.callback_query(ShippingFlow.destination, F.data.startswith("shipping_destination:"))
async def shipping_destination(callback: CallbackQuery, state: FSMContext):
    try:
        index = int(callback.data.split(":", 1)[1])
        location = config["shipping"]["locations"][index]
    except (ValueError, IndexError):
        await callback.answer("Пункт не найден.", show_alert=True)
        return
    data = await state.get_data()
    if index == data["origin_index"]:
        await callback.answer("Пункт прибытия должен отличаться от пункта отправления.", show_alert=True)
        return

    address = _location_address(location, data["transport"])
    await state.update_data(
        destination_index=index,
        destination_name=location["name"],
        destination_address=address,
    )
    await state.set_state(ShippingFlow.departure)
    await callback.message.answer(
        f"Прибытие: <b>{escape(location['name'])}</b>\n"
        f"{escape(address)}\n\n"
        "Введите дату и время отправления в формате ДД.ММ.ГГГГ ЧЧ:ММ\n"
        "Например: 25.12.2026 14:30",
        parse_mode="HTML",
        reply_markup=build_cancel_inline(),
    )
    await callback.answer()


@router.message(ShippingFlow.departure, ~F.text.in_(MAIN_MENU_BUTTONS))
async def shipping_departure(message: Message, state: FSMContext):
    raw_value = (message.text or "").strip()
    if not re.fullmatch(r"\d{2}\.\d{2}\.\d{4} \d{2}:\d{2}", raw_value):
        await message.answer("Неверный формат. Пример: 25.12.2026 14:30")
        return
    try:
        departure = datetime.strptime(raw_value, DATETIME_FORMAT)
    except ValueError:
        await message.answer("Неверный формат. Пример: 25.12.2026 14:30")
        return
    data = await state.get_data()
    locations = config["shipping"]["locations"]
    origin_offset = float(locations[data["origin_index"]]["utc_offset_hours"])
    utc_now = datetime.now(timezone.utc).replace(tzinfo=None)
    if departure <= utc_now + timedelta(hours=origin_offset):
        await message.answer("Дата и время отправления должны быть в будущем.")
        return

    distance, duration, arrival = estimate_route(
        locations[data["origin_index"]],
        locations[data["destination_index"]],
        data["transport"],
        departure,
        config["shipping"],
    )
    await state.update_data(
        departure_at=departure.isoformat(),
        distance_km=distance,
        duration_minutes=duration,
        arrival_at=arrival.isoformat(),
    )
    await state.set_state(ShippingFlow.contact)
    updated = await state.get_data()
    await message.answer(
        "<b>Предварительный расчёт</b>\n\n"
        f"{_route_text(updated)}\n\n"
        "Срок ориентировочный и зависит от погоды, маршрута и портовых/аэропортовых процедур.\n\n"
        "Укажите телефон или email для связи:",
        parse_mode="HTML",
        reply_markup=build_cancel_inline(),
    )


@router.message(ShippingFlow.contact, ~F.text.in_(MAIN_MENU_BUTTONS))
async def shipping_contact(message: Message, state: FSMContext):
    contact = (message.text or "").strip()
    if not contact:
        await message.answer("Пожалуйста, отправьте контакт текстовым сообщением.")
        return
    if len(contact) > 200:
        await message.answer("Контакт слишком длинный. Максимум: 200 символов.")
        return
    await state.update_data(contact=contact)
    data = await state.get_data()
    await state.set_state(ShippingFlow.confirm)
    await message.answer(
        "<b>Проверьте заявку</b>\n\n"
        f"{_route_text(data)}\n"
        f"Контакт: {escape(data['contact'])}",
        parse_mode="HTML",
        reply_markup=_confirmation_keyboard(),
    )


@router.callback_query(ShippingFlow.confirm, F.data == "shipping_confirm")
async def shipping_confirm(callback: CallbackQuery, state: FSMContext):
    await callback.answer("Обрабатываем заявку...")
    data = await state.get_data()
    origin = f"{data['origin_name']}: {data['origin_address']}"
    destination = f"{data['destination_name']}: {data['destination_address']}"

    db = await get_db()
    try:
        cursor = await db.execute(
            """INSERT INTO shipping_requests
               (tg_id, transport, origin, destination, departure_at, distance_km,
                duration_minutes, arrival_at, contact)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                callback.from_user.id,
                data["transport"],
                origin,
                destination,
                data["departure_at"],
                data["distance_km"],
                data["duration_minutes"],
                data["arrival_at"],
                data["contact"],
            ),
        )
        await db.commit()
        request_id = cursor.lastrowid
    finally:
        await db.close()
    await state.clear()

    delivered = await send_request_email(
        f"Заявка на перевозку #{request_id}",
        "Новая заявка на перевозку\n\n"
        f"Номер: {request_id}\n"
        f"Telegram ID: {callback.from_user.id}\n"
        f"Транспорт: {TRANSPORT_NAMES[data['transport']]}\n"
        f"Откуда: {origin}\n"
        f"Куда: {destination}\n"
        f"Отправление: {data['departure_at']}\n"
        f"Расстояние: {data['distance_km']} км\n"
        f"Время в пути: {format_duration(data['duration_minutes'])}\n"
        f"Прибытие: {data['arrival_at']}\n"
        f"Контакт: {data['contact']}",
    )
    status = "Заявка отправлена." if delivered else (
        "Заявка сохранена, но письмо не отправлено. Проверьте настройки SMTP."
    )
    await callback.message.answer(
        f"{status}\nНомер заявки: <b>#{request_id}</b>",
        parse_mode="HTML",
        reply_markup=build_back_button(),
    )


@router.callback_query(
    StateFilter(
        ShippingFlow.transport,
        ShippingFlow.origin,
        ShippingFlow.destination,
        ShippingFlow.departure,
        ShippingFlow.contact,
        ShippingFlow.confirm,
    ),
    F.data.in_({"cancel", "shipping_cancel"}),
)
async def shipping_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.answer("Заявка отменена.", reply_markup=build_back_button())
    await callback.answer()
