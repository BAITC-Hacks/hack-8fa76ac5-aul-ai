"""
MODULE: booking
Многошаговая запись: услуга → мастер → дата → время → подтверждение → БД.
Данные об услугах и мастерах — в config.json (добавьте секцию "booking").
"""
from datetime import date, timedelta
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter

from core.loader import config
from core.keyboards import build_back_button
from core.database import get_db

router = Router()

# ── Конфиг записи (если не задан — используем дефолт) ─────────────────────────
BOOKING_CONFIG = config.get("booking", {
    "services": [
        {"name": "Маникюр классический", "price": "1500₽", "duration": "60 мин"},
        {"name": "Маникюр с покрытием",  "price": "2000₽", "duration": "90 мин"},
        {"name": "Педикюр классический", "price": "2000₽", "duration": "90 мин"},
    ],
    "masters": ["Анна", "Мария", "Екатерина"],
    "time_slots": ["10:00", "11:30", "13:00", "14:30", "16:00", "17:30", "19:00"],
    "days_ahead": 7
})


# ── FSM States ────────────────────────────────────────────────────────────────
class BookingFlow(StatesGroup):
    choosing_service  = State()
    choosing_master   = State()
    choosing_date     = State()
    choosing_time     = State()
    confirm           = State()


# ── Helpers ───────────────────────────────────────────────────────────────────
def _inline(rows: list[list[tuple[str, str]]]) -> InlineKeyboardMarkup:
    """rows = [ [(text, callback_data), ...], ... ]"""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=t, callback_data=cd) for t, cd in row]
        for row in rows
    ])


def _services_kb() -> InlineKeyboardMarkup:
    rows = [
        [(f"{s['name']} — {s['price']}", f"book_service:{i}")]
        for i, s in enumerate(BOOKING_CONFIG["services"])
    ]
    rows.append([("❌ Отмена", "cancel")])
    return _inline(rows)


def _masters_kb() -> InlineKeyboardMarkup:
    rows = [
        [(m, f"book_master:{i}")]
        for i, m in enumerate(BOOKING_CONFIG["masters"])
    ]
    rows.append([("❌ Отмена", "cancel")])
    return _inline(rows)


def _dates_kb() -> InlineKeyboardMarkup:
    days = int(BOOKING_CONFIG.get("days_ahead", 7))
    today = date.today()
    days_ru = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]
    rows = []
    for i in range(days):
        d = today + timedelta(days=i)
        day_name = days_ru[d.weekday()]
        label = f"{d.day:02d}.{d.month:02d} ({day_name})"
        rows.append([(label, f"book_date:{d.isoformat()}")])
    rows.append([("❌ Отмена", "cancel")])
    return _inline(rows)


def _times_kb() -> InlineKeyboardMarkup:
    slots = BOOKING_CONFIG["time_slots"]
    # 3 кнопки в ряд
    rows = [
        [(t, f"book_time:{t}") for t in slots[i:i + 3]]
        for i in range(0, len(slots), 3)
    ]
    rows.append([("❌ Отмена", "cancel")])
    return _inline(rows)


# ── Step 1: вход ──────────────────────────────────────────────────────────────
@router.message(F.text == config["modules"]["booking"]["button_text"])
async def booking_start(message: Message, state: FSMContext):
    await state.set_state(BookingFlow.choosing_service)
    await message.answer(
        text="📅 <b>Запись на услугу</b>\n\nВыберите услугу:",
        parse_mode="HTML",
        reply_markup=_services_kb()
    )


# ── Step 2: выбрали услугу ────────────────────────────────────────────────────
@router.callback_query(BookingFlow.choosing_service, F.data.startswith("book_service:"))
async def booking_service(callback: CallbackQuery, state: FSMContext):
    idx = int(callback.data.split(":")[1])
    if idx >= len(BOOKING_CONFIG["services"]):
        await callback.answer("Ошибка. Попробуйте снова.", show_alert=True)
        return
    service = BOOKING_CONFIG["services"][idx]
    await state.update_data(service=service["name"])
    await state.set_state(BookingFlow.choosing_master)

    await callback.message.answer(
        text=f"✅ Услуга: <b>{service['name']}</b>\n\nВыберите мастера:",
        parse_mode="HTML",
        reply_markup=_masters_kb()
    )
    await callback.answer()


# ── Step 3: выбрали мастера ───────────────────────────────────────────────────
@router.callback_query(BookingFlow.choosing_master, F.data.startswith("book_master:"))
async def booking_master(callback: CallbackQuery, state: FSMContext):
    idx = int(callback.data.split(":")[1])
    if idx >= len(BOOKING_CONFIG["masters"]):
        await callback.answer("Ошибка. Попробуйте снова.", show_alert=True)
        return
    master = BOOKING_CONFIG["masters"][idx]
    await state.update_data(master=master)
    await state.set_state(BookingFlow.choosing_date)

    await callback.message.answer(
        text=f"✅ Мастер: <b>{master}</b>\n\nВыберите дату:",
        parse_mode="HTML",
        reply_markup=_dates_kb()
    )
    await callback.answer()


# ── Step 4: выбрали дату ──────────────────────────────────────────────────────
@router.callback_query(BookingFlow.choosing_date, F.data.startswith("book_date:"))
async def booking_date(callback: CallbackQuery, state: FSMContext):
    date_str = callback.data.split(":")[1]
    await state.update_data(date=date_str)
    await state.set_state(BookingFlow.choosing_time)

    await callback.message.answer(
        text=f"✅ Дата: <b>{date_str}</b>\n\nВыберите время:",
        parse_mode="HTML",
        reply_markup=_times_kb()
    )
    await callback.answer()


# ── Step 5: выбрали время ─────────────────────────────────────────────────────
@router.callback_query(BookingFlow.choosing_time, F.data.startswith("book_time:"))
async def booking_time(callback: CallbackQuery, state: FSMContext):
    time_slot = callback.data.split(":")[1]
    await state.update_data(time_slot=time_slot)
    data = await state.get_data()
    await state.set_state(BookingFlow.confirm)

    await callback.message.answer(
        text=(
            "📋 <b>Подтвердите запись:</b>\n\n"
            f"💅 Услуга: <b>{data['service']}</b>\n"
            f"👩 Мастер: <b>{data['master']}</b>\n"
            f"📆 Дата:   <b>{data['date']}</b>\n"
            f"🕐 Время:  <b>{data['time_slot']}</b>"
        ),
        parse_mode="HTML",
        reply_markup=_inline([
            [("✅ Подтвердить", "book_confirm"), ("❌ Отмена", "cancel")]
        ])
    )
    await callback.answer()


# ── Step 6: подтверждение → запись в БД ──────────────────────────────────────
@router.callback_query(BookingFlow.confirm, F.data == "book_confirm")
async def booking_confirm(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    await state.clear()

    db = await get_db()
    try:
        await db.execute(
            """INSERT INTO bookings (tg_id, service, master, date, time_slot)
               VALUES (?, ?, ?, ?, ?)""",
            (callback.from_user.id, data["service"], data["master"],
             data["date"], data["time_slot"])
        )
        await db.commit()
    finally:
        await db.close()

    await callback.message.answer(
        text=(
            "🎉 <b>Запись подтверждена!</b>\n\n"
            f"Ждём вас <b>{data['date']}</b> в <b>{data['time_slot']}</b>.\n"
            "Если нужно отменить — напишите менеджеру заранее."
        ),
        parse_mode="HTML",
        reply_markup=build_back_button()
    )
    await callback.answer()


# ── Отмена (из любого шага) ───────────────────────────────────────────────────
@router.callback_query(
    StateFilter(BookingFlow.choosing_service, BookingFlow.choosing_master, 
    BookingFlow.choosing_date, BookingFlow.choosing_time, BookingFlow.confirm),
    F.data == "cancel"
)
async def booking_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.answer(
        "Запись отменена. Возвращаемся в меню.",
        reply_markup=build_back_button()
    )
    await callback.answer()
