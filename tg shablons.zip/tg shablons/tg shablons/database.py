import aiosqlite
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "bot.db")


async def get_db() -> aiosqlite.Connection:
    """Return an open DB connection. Caller is responsible for closing."""
    return await aiosqlite.connect(DB_PATH)


async def init_db():
    """Create all tables on first launch. Safe to call every startup."""
    async with aiosqlite.connect(DB_PATH) as db:
        # ── Users ──────────────────────────────────────────────────────────
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id          INTEGER PRIMARY KEY,
                tg_id       INTEGER UNIQUE NOT NULL,
                username    TEXT,
                full_name   TEXT,
                phone       TEXT,
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # ── Reviews ────────────────────────────────────────────────────────
        await db.execute("""
            CREATE TABLE IF NOT EXISTS reviews (
                id          INTEGER PRIMARY KEY,
                tg_id       INTEGER NOT NULL,
                text        TEXT NOT NULL,
                rating      INTEGER CHECK(rating BETWEEN 1 AND 5),
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # ── Bookings ───────────────────────────────────────────────────────
        await db.execute("""
            CREATE TABLE IF NOT EXISTS bookings (
                id          INTEGER PRIMARY KEY,
                tg_id       INTEGER NOT NULL,
                service     TEXT,
                master      TEXT,
                date        TEXT,
                time_slot   TEXT,
                status      TEXT DEFAULT 'pending',
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.commit()
