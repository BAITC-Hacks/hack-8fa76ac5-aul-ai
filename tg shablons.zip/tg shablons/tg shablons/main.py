import asyncio
import os
import logging

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import SimpleEventIsolation
from dotenv import load_dotenv

from core.loader import load_config, register_modules
from core.keyboards import build_main_menu
from core.database import init_db

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
log = logging.getLogger(__name__)

# ── Environment ───────────────────────────────────────────────────────────────
load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN is not set. Copy .env.example -> .env and fill in the token.")

# ── Core objects ──────────────────────────────────────────────────────────────
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(events_isolation=SimpleEventIsolation())


# ── /start handler ────────────────────────────────────────────────────────────
@dp.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    """
    Entry point. Saves user to DB, shows welcome text + main menu.
    """
    from core.loader import config
    from core.database import get_db

    await state.clear()

    # Upsert user record
    db = await get_db()
    try:
        await db.execute("""
            INSERT INTO users (tg_id, username, full_name)
            VALUES (?, ?, ?)
            ON CONFLICT(tg_id) DO UPDATE SET
                username  = excluded.username,
                full_name = excluded.full_name
        """, (
            message.from_user.id,
            message.from_user.username,
            message.from_user.full_name
        ))
        await db.commit()
    finally:
        await db.close()

    await message.answer(
        text=config["welcome_text"],
        reply_markup=build_main_menu(config)
    )


# ── "← Назад в меню" — universal back button, handled at top level ────────────
@dp.message(F.text == "← Назад в меню")
async def back_to_menu(message: Message, state: FSMContext):
    from core.loader import config
    await state.clear()
    await message.answer(
        text=config["welcome_text"],
        reply_markup=build_main_menu(config)
    )


# ── Startup ───────────────────────────────────────────────────────────────────
async def main():
    log.info("Starting bot...")

    # 1. Load config
    cfg = load_config()
    log.info(f"Business: {cfg['business_name']} | Type: {cfg['business_type']}")

    # 2. Init database
    await init_db()
    log.info("Database ready.")

    # 3. Register only enabled modules
    log.info("Loading modules:")
    register_modules(dp)

    # 4. Start polling
    log.info("Bot is running. Press Ctrl+C to stop.")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
