import aiosqlite
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "bot.db")


async def get_db() -> aiosqlite.Connection:
    """Return an open DB connection. Caller is responsible for closing."""
    db = await aiosqlite.connect(DB_PATH)
    db.row_factory = aiosqlite.Row
    return db


async def init_db():
    """Create all tables on first launch. Safe to call every startup."""
    async with aiosqlite.connect(DB_PATH) as db:
        # ── Users ──────────────────────────────────────────────────────────
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id          INTEGER PRIMARY KEY,
                tg_id       INTEGER UNIQUE NOT NULL,
                username    TEXT,
                full_name   TEXT,
                phone       TEXT,
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Заявки в техподдержку
        await db.execute("""
            CREATE TABLE IF NOT EXISTS support_requests (
                id          INTEGER PRIMARY KEY,
                tg_id       INTEGER NOT NULL,
                full_name   TEXT NOT NULL,
                contact     TEXT NOT NULL,
                message     TEXT NOT NULL,
                status      TEXT DEFAULT 'new',
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Заявки на аренду склада
        await db.execute("""
            CREATE TABLE IF NOT EXISTS warehouse_requests (
                id          INTEGER PRIMARY KEY,
                tg_id       INTEGER NOT NULL,
                warehouse_name TEXT NOT NULL,
                warehouse_address TEXT NOT NULL,
                date_from   TEXT NOT NULL,
                date_to     TEXT NOT NULL,
                contact     TEXT NOT NULL,
                status      TEXT DEFAULT 'new',
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Заявки на перевозку полного самолёта или судна
        await db.execute("""
            CREATE TABLE IF NOT EXISTS shipping_requests (
                id          INTEGER PRIMARY KEY,
                tg_id       INTEGER NOT NULL,
                transport   TEXT NOT NULL,
                origin      TEXT NOT NULL,
                destination TEXT NOT NULL,
                departure_at TEXT NOT NULL,
                distance_km INTEGER NOT NULL,
                duration_minutes INTEGER NOT NULL,
                arrival_at  TEXT NOT NULL,
                contact     TEXT NOT NULL,
                status      TEXT DEFAULT 'new',
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.commit()
