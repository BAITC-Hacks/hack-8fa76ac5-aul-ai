from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from typing import Any


def build_main_menu(config: dict) -> ReplyKeyboardMarkup:
    """
    Builds the main menu keyboard from config.
    Only buttons whose module is enabled will appear.
    Order follows the order of keys in config["modules"].
    """
    buttons = []

    for module_key, module_cfg in config["modules"].items():
        if module_cfg.get("enabled", False):
            buttons.append(KeyboardButton(text=module_cfg["button_text"]))

    # Arrange in rows of 2, last row centred if odd count
    rows = [buttons[i:i + 2] for i in range(0, len(buttons), 2)]

    return ReplyKeyboardMarkup(
        keyboard=rows,
        resize_keyboard=True,
        input_field_placeholder="Выберите раздел..."
    )


def build_back_button() -> ReplyKeyboardMarkup:
    """Single '← Назад' button — returns user to main menu."""
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="← Назад в меню")]],
        resize_keyboard=True
    )


def build_faq_inline(faq_items: list[dict]) -> InlineKeyboardMarkup:
    """
    Inline buttons for each FAQ question.
    callback_data = "faq:{index}"
    """
    buttons = [
        [InlineKeyboardButton(
            text=item["question"],
            callback_data=f"faq:{i}"
        )]
        for i, item in enumerate(faq_items)
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def build_rating_inline() -> InlineKeyboardMarkup:
    """Star rating buttons for reviews: 1–5."""
    stars = ["⭐", "⭐⭐", "⭐⭐⭐", "⭐⭐⭐⭐", "⭐⭐⭐⭐⭐"]
    buttons = [
        [InlineKeyboardButton(text=star, callback_data=f"rating:{i + 1}")]
        for i, star in enumerate(stars)
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def build_cancel_inline() -> InlineKeyboardMarkup:
    """Single inline 'Cancel' button used during multi-step flows."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Отмена", callback_data="cancel")]
    ])
