from datetime import datetime, timedelta
from math import asin, cos, radians, sin, sqrt


def distance_km(origin: dict, destination: dict) -> float:
    """Calculate great-circle distance between configured logistics hubs."""
    lat1, lon1 = radians(origin["latitude"]), radians(origin["longitude"])
    lat2, lon2 = radians(destination["latitude"]), radians(destination["longitude"])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    value = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    return 6371 * 2 * asin(sqrt(value))


def estimate_route(
    origin: dict,
    destination: dict,
    transport: str,
    departure_at: datetime,
    settings: dict,
) -> tuple[int, int, datetime]:
    direct_distance = distance_km(origin, destination)

    if transport == "air":
        route_distance = direct_distance
        hours = route_distance / float(settings["air_speed_kmh"])
        hours += float(settings["air_handling_hours"])
    elif transport == "sea":
        route_distance = direct_distance * float(settings["sea_route_factor"])
        hours = route_distance / float(settings["sea_speed_kmh"])
        hours += float(settings["sea_handling_hours"])
    else:
        raise ValueError("Unknown transport type")

    duration_minutes = max(1, round(hours * 60))
    origin_offset = float(origin.get("utc_offset_hours", 0))
    destination_offset = float(destination.get("utc_offset_hours", 0))
    departure_utc = departure_at - timedelta(hours=origin_offset)
    arrival_at = (
        departure_utc
        + timedelta(minutes=duration_minutes)
        + timedelta(hours=destination_offset)
    )
    return round(route_distance), duration_minutes, arrival_at


def format_duration(minutes: int) -> str:
    days, remainder = divmod(minutes, 24 * 60)
    hours, mins = divmod(remainder, 60)
    parts = []
    if days:
        parts.append(f"{days} дн.")
    if hours:
        parts.append(f"{hours} ч.")
    if mins or not parts:
        parts.append(f"{mins} мин.")
    return " ".join(parts)
