import asyncio
import os
import smtplib
from email.message import EmailMessage

from core.loader import config


async def send_request_email(subject: str, body: str) -> bool:
    """Send a plain-text request email. Returns False when SMTP is not configured."""
    host = os.getenv("SMTP_HOST")
    username = os.getenv("SMTP_USERNAME")
    password = os.getenv("SMTP_PASSWORD")
    sender = os.getenv("SMTP_FROM") or username
    recipient = config.get("notifications", {}).get("request_email")

    if not all((host, username, password, sender, recipient)):
        return False

    try:
        port = int(os.getenv("SMTP_PORT", "587"))
    except ValueError:
        return False
    use_starttls = os.getenv("SMTP_STARTTLS", "true").lower() in {"1", "true", "yes"}

    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = sender
    message["To"] = recipient
    message.set_content(body)

    def _send() -> None:
        with smtplib.SMTP(host, port, timeout=20) as smtp:
            if use_starttls:
                smtp.starttls()
            smtp.login(username, password)
            smtp.send_message(message)

    try:
        await asyncio.to_thread(_send)
    except (OSError, smtplib.SMTPException):
        return False
    return True
