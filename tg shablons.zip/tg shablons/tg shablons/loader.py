import json
import importlib
import os
from aiogram import Dispatcher

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "..", "config.json")

# Global config object — loaded once, used everywhere
config: dict = {}


def load_config() -> dict:
    """Read config.json and cache it in the global `config` variable."""
    global config
    with open(CONFIG_PATH, encoding="utf-8") as f:
        config = json.load(f)
    return config


def register_modules(dp: Dispatcher):
    """
    Scan config["modules"], import each enabled module's router.py,
    and include its `router` object into the Dispatcher.

    To add a NEW module:
      1. Create  modules/<name>/router.py  with an aiogram Router named `router`
      2. Add the module key to config.json → "modules" with enabled/button_text
      That's it. Nothing else to change.
    """
    for module_key, module_cfg in config["modules"].items():
        if not module_cfg.get("enabled", False):
            print(f"  [ ] Module '{module_key}' — DISABLED, skipping")
            continue

        try:
            module = importlib.import_module(f"modules.{module_key}.router")
            dp.include_router(module.router)
            print(f"  [✓] Module '{module_key}' — loaded")
        except ModuleNotFoundError:
            print(f"  [!] Module '{module_key}' — router.py not found, skipping")
        except AttributeError:
            print(f"  [!] Module '{module_key}' — no `router` object in router.py, skipping")
